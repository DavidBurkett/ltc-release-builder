/*
	File:           AVMIDIPlayer.h
	Framework:      AVFoundation
	
	Copyright 2016 Apple Inc. All rights reserved.
*/

#import <AVFAudio/AVMIDIPlayer.h>

